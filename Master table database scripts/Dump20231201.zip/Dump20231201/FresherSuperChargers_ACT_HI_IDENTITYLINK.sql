-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: freshersuperchargers.czbdrgtkozjs.us-east-1.rds.amazonaws.com    Database: FresherSuperChargers
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `ACT_HI_IDENTITYLINK`
--

DROP TABLE IF EXISTS `ACT_HI_IDENTITYLINK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ACT_HI_IDENTITYLINK` (
  `ID_` varchar(64) COLLATE utf8mb3_bin NOT NULL,
  `TIMESTAMP_` timestamp NOT NULL,
  `TYPE_` varchar(255) COLLATE utf8mb3_bin DEFAULT NULL,
  `USER_ID_` varchar(255) COLLATE utf8mb3_bin DEFAULT NULL,
  `GROUP_ID_` varchar(255) COLLATE utf8mb3_bin DEFAULT NULL,
  `TASK_ID_` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL,
  `ROOT_PROC_INST_ID_` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL,
  `PROC_DEF_ID_` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL,
  `OPERATION_TYPE_` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL,
  `ASSIGNER_ID_` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL,
  `PROC_DEF_KEY_` varchar(255) COLLATE utf8mb3_bin DEFAULT NULL,
  `TENANT_ID_` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL,
  `REMOVAL_TIME_` datetime DEFAULT NULL,
  PRIMARY KEY (`ID_`),
  KEY `ACT_IDX_HI_IDENT_LNK_ROOT_PI` (`ROOT_PROC_INST_ID_`),
  KEY `ACT_IDX_HI_IDENT_LNK_USER` (`USER_ID_`),
  KEY `ACT_IDX_HI_IDENT_LNK_GROUP` (`GROUP_ID_`),
  KEY `ACT_IDX_HI_IDENT_LNK_TENANT_ID` (`TENANT_ID_`),
  KEY `ACT_IDX_HI_IDENT_LNK_PROC_DEF_KEY` (`PROC_DEF_KEY_`),
  KEY `ACT_IDX_HI_IDENT_LINK_TASK` (`TASK_ID_`),
  KEY `ACT_IDX_HI_IDENT_LINK_RM_TIME` (`REMOVAL_TIME_`),
  KEY `ACT_IDX_HI_IDENT_LNK_TIMESTAMP` (`TIMESTAMP_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ACT_HI_IDENTITYLINK`
--

LOCK TABLES `ACT_HI_IDENTITYLINK` WRITE;
/*!40000 ALTER TABLE `ACT_HI_IDENTITYLINK` DISABLE KEYS */;
INSERT INTO `ACT_HI_IDENTITYLINK` VALUES ('0277d2ff-885c-11ee-8d4b-1244bd7b236f','2023-11-21 10:52:05','assignee','Test',NULL,'cd9a7fb9-885b-11ee-8d4b-1244bd7b236f','b7d0f3f5-885b-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add','Test','Decision',NULL,NULL),('0540f73d-8857-11ee-8d4b-1244bd7b236f','2023-11-21 10:16:23','candidate',NULL,'JAVA','0540f73b-8857-11ee-8d4b-1244bd7b236f','8ca40ba1-8856-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add',NULL,'Decision',NULL,NULL),('0a0dc4f7-885b-11ee-8d4b-1244bd7b236f','2023-11-21 10:45:09','assignee','Sandipan',NULL,'f0454661-885a-11ee-8d4b-1244bd7b236f','bd78f967-885a-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add','Sandipan','Decision',NULL,NULL),('2f6c6811-8857-11ee-8d4b-1244bd7b236f','2023-11-21 10:17:33','assignee','Sandipan',NULL,'0540f73b-8857-11ee-8d4b-1244bd7b236f','8ca40ba1-8856-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add','Sandipan','Decision',NULL,NULL),('3a15df16-885a-11ee-8d4b-1244bd7b236f','2023-11-21 10:39:20','assignee','Sandipan',NULL,'b53e4d90-8859-11ee-8d4b-1244bd7b236f','9f6e592c-8859-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add','Sandipan','Decision',NULL,NULL),('5635ecec-885b-11ee-8d4b-1244bd7b236f','2023-11-21 10:47:16','candidate',NULL,'JAVA','5635ecea-885b-11ee-8d4b-1244bd7b236f','4c8a2fa6-885b-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add',NULL,'Decision',NULL,NULL),('58ba4de0-885b-11ee-8d4b-1244bd7b236f','2023-11-21 10:47:21','assignee','Test',NULL,'5635ecea-885b-11ee-8d4b-1244bd7b236f','4c8a2fa6-885b-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add','Test','Decision',NULL,NULL),('5af231f8-885a-11ee-8d4b-1244bd7b236f','2023-11-21 10:40:15','candidate',NULL,'JAVA','5af20ae6-885a-11ee-8d4b-1244bd7b236f','9f6e592c-8859-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add',NULL,'Decision',NULL,NULL),('600924ac-885a-11ee-8d4b-1244bd7b236f','2023-11-21 10:40:23','assignee','Sandipan',NULL,'5af20ae6-885a-11ee-8d4b-1244bd7b236f','9f6e592c-8859-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add','Sandipan','Decision',NULL,NULL),('6fcc3822-885b-11ee-8d4b-1244bd7b236f','2023-11-21 10:47:59','candidate',NULL,'JAVA','6fcc3820-885b-11ee-8d4b-1244bd7b236f','4c8a2fa6-885b-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add',NULL,'Decision',NULL,NULL),('802692f0-8a5c-11ee-8d4b-1244bd7b236f','2023-11-24 00:00:39','candidate',NULL,'AWS','802692ee-8a5c-11ee-8d4b-1244bd7b236f','69af630a-8a5c-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add',NULL,'Decision',NULL,NULL),('8ce60496-885b-11ee-8d4b-1244bd7b236f','2023-11-21 10:48:48','assignee','Sandipan',NULL,'6fcc3820-885b-11ee-8d4b-1244bd7b236f','4c8a2fa6-885b-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add','Sandipan','Decision',NULL,NULL),('a28abc57-8856-11ee-8d4b-1244bd7b236f','2023-11-21 10:13:37','candidate',NULL,'JAVA','a28a9545-8856-11ee-8d4b-1244bd7b236f','8ca40ba1-8856-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add',NULL,'Decision',NULL,NULL),('b53e74a2-8859-11ee-8d4b-1244bd7b236f','2023-11-21 10:35:37','candidate',NULL,'JAVA','b53e4d90-8859-11ee-8d4b-1244bd7b236f','9f6e592c-8859-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add',NULL,'Decision',NULL,NULL),('c735ccad-885a-11ee-8d4b-1244bd7b236f','2023-11-21 10:43:17','candidate',NULL,'JAVA','c735ccab-885a-11ee-8d4b-1244bd7b236f','bd78f967-885a-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add',NULL,'Decision',NULL,NULL),('cd9a7fbb-885b-11ee-8d4b-1244bd7b236f','2023-11-21 10:50:37','candidate',NULL,'AWS','cd9a7fb9-885b-11ee-8d4b-1244bd7b236f','b7d0f3f5-885b-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add',NULL,'Decision',NULL,NULL),('d1e64d2b-8856-11ee-8d4b-1244bd7b236f','2023-11-21 10:14:57','assignee','Sandipan',NULL,'a28a9545-8856-11ee-8d4b-1244bd7b236f','8ca40ba1-8856-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add','Sandipan','Decision',NULL,NULL),('de06b621-885a-11ee-8d4b-1244bd7b236f','2023-11-21 10:43:55','assignee','Sandipan',NULL,'c735ccab-885a-11ee-8d4b-1244bd7b236f','bd78f967-885a-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add','Sandipan','Decision',NULL,NULL),('f0454663-885a-11ee-8d4b-1244bd7b236f','2023-11-21 10:44:25','candidate',NULL,'JAVA','f0454661-885a-11ee-8d4b-1244bd7b236f','bd78f967-885a-11ee-8d4b-1244bd7b236f','Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','add',NULL,'Decision',NULL,NULL);
/*!40000 ALTER TABLE `ACT_HI_IDENTITYLINK` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-01 23:47:17
