-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: freshersuperchargers.czbdrgtkozjs.us-east-1.rds.amazonaws.com    Database: FresherSuperChargers
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `ACT_RU_JOBDEF`
--

DROP TABLE IF EXISTS `ACT_RU_JOBDEF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ACT_RU_JOBDEF` (
  `ID_` varchar(64) COLLATE utf8mb3_bin NOT NULL,
  `REV_` int DEFAULT NULL,
  `PROC_DEF_ID_` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL,
  `PROC_DEF_KEY_` varchar(255) COLLATE utf8mb3_bin DEFAULT NULL,
  `ACT_ID_` varchar(255) COLLATE utf8mb3_bin DEFAULT NULL,
  `JOB_TYPE_` varchar(255) COLLATE utf8mb3_bin NOT NULL,
  `JOB_CONFIGURATION_` varchar(255) COLLATE utf8mb3_bin DEFAULT NULL,
  `SUSPENSION_STATE_` int DEFAULT NULL,
  `JOB_PRIORITY_` bigint DEFAULT NULL,
  `TENANT_ID_` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL,
  `DEPLOYMENT_ID_` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL,
  PRIMARY KEY (`ID_`),
  KEY `ACT_IDX_JOBDEF_TENANT_ID` (`TENANT_ID_`),
  KEY `ACT_IDX_JOBDEF_PROC_DEF_ID` (`PROC_DEF_ID_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ACT_RU_JOBDEF`
--

LOCK TABLES `ACT_RU_JOBDEF` WRITE;
/*!40000 ALTER TABLE `ACT_RU_JOBDEF` DISABLE KEYS */;
INSERT INTO `ACT_RU_JOBDEF` VALUES ('1e62dd39-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Activity_0mr9cro','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd3a-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Activity_09dfzbs','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd3b-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Activity_14j5lpe','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd3c-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Activity_1kx2h17','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd3d-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Activity_1f5gqd6','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd3e-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Activity_0e0vm77','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd3f-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Activity_0g80o6f','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd40-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Activity_0nlje28','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd41-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Activity_17hqax8','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd42-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Activity_053dzbs','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd43-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Activity_1xyq23s','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd44-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Activity_1nfawup','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd45-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Activity_1eaudzw','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd46-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Event_0fiztls','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd47-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Event_0fiztls','timer-intermediate-transition','DURATION: PT15S',1,NULL,NULL,NULL),('1e62dd48-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Event_0bwll51','async-continuation','async-after',1,NULL,NULL,NULL),('1e62dd49-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Event_0bwll51','timer-intermediate-transition','DURATION: PT15S',1,NULL,NULL,NULL),('1e62dd4a-8854-11ee-8d4b-1244bd7b236f',1,'Decision:1:1e62b628-8854-11ee-8d4b-1244bd7b236f','Decision','Event_1tsc1be','timer-intermediate-transition','DURATION: P2D',1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `ACT_RU_JOBDEF` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-01 23:39:51
