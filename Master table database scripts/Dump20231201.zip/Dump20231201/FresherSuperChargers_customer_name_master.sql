-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: freshersuperchargers.czbdrgtkozjs.us-east-1.rds.amazonaws.com    Database: FresherSuperChargers
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `customer_name_master`
--

DROP TABLE IF EXISTS `customer_name_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_name_master` (
  `uid` int NOT NULL,
  `customer_name` varchar(512) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NULL DEFAULT NULL,
  `created_by` varchar(512) DEFAULT NULL,
  `update_by` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_name_master`
--

LOCK TABLES `customer_name_master` WRITE;
/*!40000 ALTER TABLE `customer_name_master` DISABLE KEYS */;
INSERT INTO `customer_name_master` VALUES (1,'HCL Technologies  Ltd.','2023-08-07 11:14:53',NULL,'admin',NULL),(2,'Not assigned','2023-08-07 11:14:53',NULL,'admin',NULL),(3,'Western Union Inc','2023-08-07 11:14:53',NULL,'admin',NULL),(4,'BlackRock, Inc.','2023-08-07 11:14:53',NULL,'admin',NULL),(5,'PayPal Inc.,','2023-08-07 11:14:53',NULL,'admin',NULL),(6,'Warp Drive Inc (dba FalconX)','2023-08-07 11:14:53',NULL,'admin',NULL),(7,'CONVERA Holding  LLC','2023-08-07 11:14:53',NULL,'admin',NULL),(8,'WM Global Technology Services','2023-08-07 11:14:53',NULL,'admin',NULL),(9,'NortonLifeLock Inc.','2023-08-07 11:14:53',NULL,'admin',NULL),(10,'Adobe Inc.','2023-08-07 11:14:53',NULL,'admin',NULL),(11,'Mastercard Technologies LLC','2023-08-07 11:14:53',NULL,'admin',NULL),(12,'Calix, Inc.','2023-08-07 11:14:53',NULL,'admin',NULL),(13,'Airtel Payment Bank Ltd','2023-08-07 11:14:53',NULL,'admin',NULL),(14,'INTEL CORP','2023-08-07 11:14:53',NULL,'admin',NULL),(15,'IKEA','2023-08-07 11:14:53',NULL,'admin',NULL),(16,'CADENT GAS LIMITED','2023-08-07 11:14:53',NULL,'admin',NULL),(17,'Workforce Logiq Sweden  AB','2023-08-07 11:14:53',NULL,'admin',NULL),(18,'Anheuser Busch InBev SA/NV','2023-08-07 11:14:53',NULL,'admin',NULL),(19,'MENTIS INC.','2023-08-07 11:14:53',NULL,'admin',NULL),(20,'FLEXIBLE LIFESTYLE EMPLOYMENT COMPA','2023-08-07 11:14:53',NULL,'admin',NULL),(21,'Pine Labs Private Limited','2023-08-07 11:14:53',NULL,'admin',NULL),(22,'PRO Unlimited, Inc.','2023-08-07 11:14:53',NULL,'admin',NULL),(23,'Dell Corporation Ltd.','2023-08-07 11:14:53',NULL,'admin',NULL),(24,'NORTHWESTERN MUTUAL','2023-08-07 11:14:53',NULL,'admin',NULL),(25,'DHL Supply Chain Solutions','2023-08-07 11:14:53',NULL,'admin',NULL),(26,'Phantom Technologies Inc','2023-08-07 11:14:53',NULL,'admin',NULL),(27,'KLA CORPORATION','2023-08-07 11:14:53',NULL,'admin',NULL);
/*!40000 ALTER TABLE `customer_name_master` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-01 23:47:06
