-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: freshersuperchargers.czbdrgtkozjs.us-east-1.rds.amazonaws.com    Database: FresherSuperChargers
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `hacker_rank_test_java`
--

DROP TABLE IF EXISTS `hacker_rank_test_java`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hacker_rank_test_java` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `ats_state` varchar(255) DEFAULT NULL,
  `attempt_count` varchar(255) DEFAULT NULL,
  `coding` varchar(255) DEFAULT NULL,
  `date_taken` varchar(255) DEFAULT NULL,
  `excel_name` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `invited_by` varchar(255) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `java_score` varchar(255) DEFAULT NULL,
  `junit_score` varchar(255) DEFAULT NULL,
  `login_id` varchar(255) DEFAULT NULL,
  `mcq` varchar(255) DEFAULT NULL,
  `max_score` varchar(255) DEFAULT NULL,
  `network_disconnect_duration` varchar(255) DEFAULT NULL,
  `percentage_score` varchar(255) DEFAULT NULL,
  `plagarism` varchar(255) DEFAULT NULL,
  `report_link` varchar(255) DEFAULT NULL,
  `rest_api_score` varchar(255) DEFAULT NULL,
  `sap_id` bigint DEFAULT NULL,
  `skill` varchar(255) DEFAULT NULL,
  `springboot_score` varchar(255) DEFAULT NULL,
  `sql_score` varchar(255) DEFAULT NULL,
  `tags` varchar(255) DEFAULT NULL,
  `time_taken` varchar(255) DEFAULT NULL,
  `total_score` varchar(255) DEFAULT NULL,
  `years_experience` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hacker_rank_test_java`
--

LOCK TABLES `hacker_rank_test_java` WRITE;
/*!40000 ALTER TABLE `hacker_rank_test_java` DISABLE KEYS */;
INSERT INTO `hacker_rank_test_java` VALUES (1,'Test Completed - Evaluation Reqd.','5.0','150.0','04-Aug-2023','Hacker Rank- 10th August','Sandipan Dandapat','Nirupam','148.64.7.21','118.333333333333','18.3333333333333','sandipan.dandapat@hcl.com','156.25','330.0','0 Secs','92.92','No','https://www.hackerrank.com/x/tests/1574190/candidates/54466479/report/?authkey=2dd05aabf7a3e7f1c9fa9baad783c1b3','95.0',52116001,'1','45.0','30.0','_','56.25 minute(s)','306.67','<1'),(2,'Test Completed - Evaluation Reqd.','6.0','129.0','10-Aug-2023','Hacker Rank- 10th August','Alagusundar G','Nirupam','168.149.184.209','109.0','20.0','ahmadtausif389@gmail.com','177.75','330.0','1 mins 8 secs','92.87','No','https://www.hackerrank.com/x/tests/1574190/candidates/54661375/report/?authkey=2dd05aabf7a3e7f1c9fa9baad783c1b3','95.0',52087286,'1','52.5','30.0','_','50.25 minute(s)','306.5','0.0'),(3,'Test Completed - Evaluation Reqd.','6.0','150.0','08-Aug-2023','Hacker Rank- 10th August','Bhuvaneshwaran.R','Nirupam','148.64.7.73','125.0','19.0','bhuvaneshravi28@gmail.com','167.5','330.0','0 Secs','0.0','Yes','https://www.hackerrank.com/x/tests/1574190/candidates/54595417/report/?authkey=2dd05aabf7a3e7f1c9fa9baad783c1b3','93.75',52087220,'1','50.0','30.0','_','21.25 minute(s)','317.75','1.0');
/*!40000 ALTER TABLE `hacker_rank_test_java` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-01 23:48:31
