-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: freshersuperchargers.czbdrgtkozjs.us-east-1.rds.amazonaws.com    Database: FresherSuperChargers
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `hacker_rank_test_java_script`
--

DROP TABLE IF EXISTS `hacker_rank_test_java_script`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hacker_rank_test_java_script` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `ats_state` varchar(255) DEFAULT NULL,
  `attempt_count` varchar(255) DEFAULT NULL,
  `coding` varchar(255) DEFAULT NULL,
  `date_taken` varchar(255) DEFAULT NULL,
  `excel_name` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `invited_by` varchar(255) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `javascript_score` varchar(255) DEFAULT NULL,
  `login_id` varchar(255) DEFAULT NULL,
  `max_score` varchar(255) DEFAULT NULL,
  `network_disconnect_duration` varchar(255) DEFAULT NULL,
  `percentage_score` varchar(255) DEFAULT NULL,
  `plagarism` varchar(255) DEFAULT NULL,
  `report_link` varchar(255) DEFAULT NULL,
  `sap_id` bigint DEFAULT NULL,
  `skill` varchar(255) DEFAULT NULL,
  `tags` varchar(255) DEFAULT NULL,
  `time_taken` varchar(255) DEFAULT NULL,
  `total_score` varchar(255) DEFAULT NULL,
  `years_experience` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hacker_rank_test_java_script`
--

LOCK TABLES `hacker_rank_test_java_script` WRITE;
/*!40000 ALTER TABLE `hacker_rank_test_java_script` DISABLE KEYS */;
INSERT INTO `hacker_rank_test_java_script` VALUES (1,'Test Completed - Evaluation Reqd.','1.0','100.0','04-Aug-2023','Hacker Rank- 10th August','Sara Javed','Nirupam','148.64.7.21','150.0','ahmadtausif38@gmail.com','250.0','0 Secs','100.0','No','https://www.hackerrank.com/x/tests/1571028/candidates/54580032/report/?authkey=ca1a12db6b0dff8e61dd33fe912fa6b3',52070399,'4','_','60.52 minute(s)','250.0','1.0'),(2,'Test Completed - Evaluation Reqd.','1.0','75.0','10-Aug-2023','Hacker Rank- 10th August','Alagusundar G','Nirupam','168.149.184.209','0.0','ahmadtausif389@gmail.com','250.0','0 Secs','0.0','Yes','https://www.hackerrank.com/x/tests/1571028/candidates/54580032/report/?authkey=ca1a12db6b0dff8e61dd33fe912fa6b3',52087286,'4','_','60.52 minute(s)','0.0','1.0'),(3,'Test Completed - Evaluation Reqd.','1.0','73.0','08-Aug-2023','Hacker Rank- 10th August','Bhuvaneshwaran.R','Nirupam','148.64.7.73','0.0','bhuvaneshravi28@gmail.com','250.0','0 Secs','0.0','Yes','https://www.hackerrank.com/x/tests/1574190/candidates/54595417/report/?authkey=2dd05aabf7a3e7f1c9fa9baad783c1b3',52087220,'4','_','60.52 minute(s)','0.0','1.0');
/*!40000 ALTER TABLE `hacker_rank_test_java_script` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-01 23:47:29
