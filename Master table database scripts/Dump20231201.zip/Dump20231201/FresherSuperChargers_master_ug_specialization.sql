-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: freshersuperchargers.czbdrgtkozjs.us-east-1.rds.amazonaws.com    Database: FresherSuperChargers
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `master_ug_specialization`
--

DROP TABLE IF EXISTS `master_ug_specialization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_ug_specialization` (
  `key` varchar(255) NOT NULL,
  `uid` int DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_ug_specialization`
--

LOCK TABLES `master_ug_specialization` WRITE;
/*!40000 ALTER TABLE `master_ug_specialization` DISABLE KEYS */;
INSERT INTO `master_ug_specialization` VALUES ('AEI',2,'AEI'),('AERO',1,'AERO'),('AGRI.',20,'AGRI'),('ARCHIT.',22,'Architectural Design'),('AUTO',3,'AUTO'),('BE',17,'BE'),('BIOTECH',23,'BIOTECH'),('CERAMIC',16,'CERAMIC'),('CHEM. ENG ',35,'Chemical Engineering'),('CIVIL',5,'CIVIL'),('CSEorCS',4,'CSE'),('ECorECE',6,'ECE'),('EE',9,'EE'),('EEE',7,'EEE'),('EIE',8,'EIE'),('ELECTRICAM',34,'Electricam'),('ETCorETE',10,'ETE'),('FPE',18,'FPE'),('GD',30,'Graphic Design '),('IEE',33,'IEE'),('ISE',11,'ISE'),('IT',13,'IT'),('MD',29,'Machine Design'),('ME',27,'Mining Engineering '),('MECH',12,'MECH'),('MECHATRONICS ',24,'Mechatronics Engineering'),('MI',19,'MI'),('MME',26,'Metallurgical and Materials Engineering'),('MSE',21,'Materials Science and Engineering'),('NAOE',25,'Naval Architecture and Ocean Engineering'),('PIE',28,'Production and Industrial Engineering'),('PSE',31,'Physical Sience Engineering'),('RA',14,'RA'),('SE',15,'SE'),('TD',32,'Textile Design');
/*!40000 ALTER TABLE `master_ug_specialization` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-01 23:49:00
