-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: freshersuperchargers.czbdrgtkozjs.us-east-1.rds.amazonaws.com    Database: FresherSuperChargers
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `task_feedback`
--

DROP TABLE IF EXISTS `task_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_feedback` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `approver` varchar(255) DEFAULT NULL,
  `remarks` longtext,
  `score` varchar(255) DEFAULT NULL,
  `task` varchar(255) DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_feedback`
--

LOCK TABLES `task_feedback` WRITE;
/*!40000 ALTER TABLE `task_feedback` DISABLE KEYS */;
INSERT INTO `task_feedback` VALUES (1,'Admin','Good','90','DATABASE',52070399),(2,'Admin','Good','85','DATABASE',52120411),(3,'Admin','Good','87','DATABASE',52120411),(4,'Sandipan','Good','80','DATABASE',52116001),(5,'Sandipan','Good','85','DATABASE',52113001),(6,'Admin','Good','90','DATABASE',52116001),(7,'Tausif','Good','80','JAVA',52116001),(8,'Admin','Good','86','AWS',52115838),(9,'Ashwini','No','75','AWS',52115838),(10,'Admin','Good','90','AWS',52115838),(11,'Aswini','Good','70','DATABASE',52127354),(12,'Ashwini','No','50','AWS',52124416),(13,'Admin','No','70','SPRINGBOOT',52109090),(14,'Sandipan','Good','85','SPRINGBOOT',52109090),(15,NULL,'Good','92.92','JAVA',52116001),(16,'Tausif','Good','89','SPRINGBOOT',52130115),(17,'Tausif','Good','80','SPRINGBOOT',52130115),(18,'Tausif','Good','80','SPRINGBOOT',52130115),(19,'Sandipan','Good','85','SPRINGBOOT',52130115),(20,'Sandipan','Good','76','SPRINGBOOT',52130115),(21,'A','jn','87','SPRINGBOOT',52130115),(22,'Admin','Good','90','SPRINGBOOT',52130115);
/*!40000 ALTER TABLE `task_feedback` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-02  0:00:30
